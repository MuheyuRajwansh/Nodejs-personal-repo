<?php
/**
 * Class forum content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Forum;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class BPCF_Forum_Content_Filter
 */
class Forum_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup callbacks for necessary hooks.
	 */
	private function setup() {
		add_filter( 'bbp_get_topic_title', array( $this, 'filter_topic_title' ) );
		add_filter( 'bbp_get_topic_content', array( $this, 'filter_topic_content' ) );
		add_filter( 'bbp_get_topic_excerpt', array( $this, 'filter_topic_excerpt' ) );
		//add_filter( 'bbp_get_topic_author_display_name', array( $this, 'filter_text' ) );
		add_filter( 'bbp_get_topic_archive_title', array( $this, 'filter_topic_archive_title' ) );
		//add_filter( 'bbp_get_topic_forum', array( $this, 'filter_text' ) );
		add_filter( 'bbp_get_reply_title', array( $this, 'filter_reply_title' ) );
		add_filter( 'bbp_get_reply_content', array( $this, 'filter_reply_content' ) );
		add_filter( 'bbp_get_reply_excerpt', array( $this, 'filter_reply_excerpt' ) );
		//add_filter( 'bbp_get_reply_author_display_name', array( $this, 'filter_text' ) );
		add_filter( 'bbp_get_forum_title', array( $this, 'filter_forum_title' ) );
		add_filter( 'bbp_get_forum_archive_title', array( $this, 'filter_forum_archive_title' ) );
		add_filter( 'bbp_get_forum_content', array( $this, 'filter_forum_content' ) );

		// Filter mail content.
		add_filter( 'bbp_subscription_mail_title', array( $this, 'filter_mail_subject' ) );
		add_filter( 'bbp_forum_subscription_mail_title', array( $this, 'filter_mail_subject' ) );
		add_filter( 'bbp_subscription_mail_message', array( $this, 'filter_mail_message' ) );
		add_filter( 'bbp_forum_subscription_mail_message', array( $this, 'filter_mail_message' ) );

		add_action( 'bbp_new_topic', array( $this, 'notify_admin' ) );
		add_action( 'bbp_new_reply', array( $this, 'notify_admin' ) );
	}

	/**
	 * Filter topic title
	 *
	 * @param string $title Title
	 *
	 * @return string
	 */
	public function filter_topic_title( $title ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_topic_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter topic content
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_topic_content( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_topic_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter topic excerpt
	 *
	 * @param string $excerpt Excerpt.
	 *
	 * @return string
	 */
	public function filter_topic_excerpt( $excerpt ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_topic_excerpt', $enable_for, true ) ) {
			return $this->get_filtered_content( $excerpt );
		}

		return $excerpt;
	}

	/**
	 * Filter topic archive title
	 *
	 * @param string $title Title.
	 *
	 * @return string
	 */
	public function filter_topic_archive_title( $title ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_topic_archive_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter reply title
	 *
	 * @param string $title Title.
	 *
	 * @return string
	 */
	public function filter_reply_title( $title ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_reply_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter reply content
	 *
	 * @param string $content Filter content.
	 *
	 * @return string
	 */
	public function filter_reply_content( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_reply_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter reply excerpt
	 *
	 * @param string $excerpt Excerpt.
	 *
	 * @return string
	 */
	public function filter_reply_excerpt( $excerpt ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_reply_excerpt', $enable_for, true ) ) {
			return $this->get_filtered_content( $excerpt );
		}

		return $excerpt;
	}

	/**
	 * Filter forum title
	 *
	 * @param string $title Forum title.
	 *
	 * @return string
	 */
	public function filter_forum_title( $title ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter forum archive title
	 *
	 * @param string $title Title.
	 *
	 * @return string
	 */
	public function filter_forum_archive_title( $title ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_archive_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter forum content.
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_forum_content( $content ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'forum_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter mail subject
	 *
	 * @param string $subject Mail subject.
	 *
	 * @return string
	 */
	public function filter_mail_subject( $subject ) {
		return $this->get_filtered_content( $subject );
	}

	/**
	 * Filter mail message
	 *
	 * @param string $message Mail message.
	 *
	 * @return string
	 */
	public function filter_mail_message( $message ) {
		return $this->get_filtered_content( $message );
	}

	/**
	 * Filter text
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	private function get_filtered_content( $content ) {
		return bp_profanity_filter_get_parsed_content( $content );
	}

	/**
	 * Notify admin when profanity content posted in activity or activity comment
	 *
	 * @param int $topic_reply_id Topic or reply id.
	 */
	public function notify_admin( $topic_reply_id ) {
		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable || bp_profanity_was_admin_notified() ) {
			return;
		}

		$post = get_post( $topic_reply_id );

		// Do not handle if not a bbPress post.
		if ( empty( $post->post_type ) || ! in_array( $post->post_type, array(
				bbp_get_topic_post_type(),
				bbp_get_reply_post_type()
			), true ) ) {
			return;
		}

		$has_profanity = bp_profanity_filter_has_profanity_content( $post->post_title ) || bp_profanity_filter_has_profanity_content( $post->post_content );

		if ( ! $has_profanity ) {
			return;
		}

		$email = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );

		if ( bbp_get_topic_post_type() == $post->post_type ) {
			$subject = __( 'A topic is posted with profanity content.', 'buddypress-profanity-filter' );

			$message = sprintf( 'Topic title: %s', $post->post_title );
			$message .= sprintf( "\n Topic content: %s", $post->post_content );
		} else {
			$subject = __( 'A reply is posted with profanity content.', 'buddypress-profanity-filter' );

			$message = sprintf( 'Reply content: %s', $post->post_content );
		}

		$message .= sprintf( "\nLink: %s", esc_url( get_edit_post_link( $post ) ) );
		bp_profanity_was_admin_notified( true );
		wp_mail( $email, $subject, $message );
	}
}