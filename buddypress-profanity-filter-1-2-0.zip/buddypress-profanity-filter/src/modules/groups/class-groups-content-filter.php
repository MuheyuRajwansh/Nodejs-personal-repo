<?php
/**
 * Class groups content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Groups;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class Groups_Content_Filter
 */
class Groups_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup on group content filters
	 */
	private function setup() {
		add_filter( 'bp_get_group_name', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_group_description', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_group_description_excerpt', array( $this, 'filter_text' ) );
		//add_filter( 'bp_get_group_creator_username', array( $self, 'filter_text' ) );

		// Notify admin when profanity content posted in group.
		add_action( 'groups_create_group', array( $this, 'notify_admin' ) );
		add_action( 'groups_update_group', array( $this, 'notify_admin' ) );
	}

	/**
	 * Filter text
	 *
	 * @param string $text Text content.
	 *
	 * @return string
	 */
	public function filter_text( $text ) {
		return bp_profanity_filter_get_parsed_content( $text );
	}

	/**
	 * Notify admin when profanity content posted in groups
	 *
	 * @param int $group_id Group id.
	 */
	public function notify_admin( $group_id ) {

		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable ) {
			return;
		}

		$group = groups_get_group( $group_id );

		$has_profanity = false;

		if ( bp_profanity_filter_has_profanity_content( $group->name ) ) {
			$has_profanity = true;
		} elseif ( bp_profanity_filter_has_profanity_content( $group->description ) ) {
			$has_profanity = true;
		}

		if ( $has_profanity ) {
			$email   = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );
			$subject = __( 'New profanity content is posted in group', 'buddypress-profanity-filter' );

			$message = 'Group name: ' . $group->name . PHP_EOL;
			$message .= 'Group desc: ' . $group->description;

			$edit_link = add_query_arg( array(
				'page'   => 'bp-groups',
				'gid'    => $group->id,
				'action' => 'edit',
			), admin_url() );

			$message .= sprintf( "\nLink: %s", esc_url( $edit_link ) );
			wp_mail( $email, $subject, $message );
		}
	}
}