<?php
/**
 * Class apply profanity on profile fields.
 *
 * @package    BuddyPress_Profanity_Filter
 * @subpackage BuddyPress
 */

namespace BuddyPress_Profanity_Filter\Modules\Profile_Fields;

// Exit if accessed directly over web.
defined( 'ABSPATH' ) || exit;

/**
 * Class Profile_Fields_Filter
 */
class Profile_Fields_Filter {

	/**
	 * Boot activity content filter class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup activity callbacks
	 */
	private function setup() {

		add_filter( 'bp_get_the_profile_field_value', array( $this, 'filter_content' ) );

		// Notify admin when profanity activity posted.
		add_action( 'xprofile_updated_profile', array( $this, 'notify_admin' ), 10, 5 );
	}

	/**
	 * Filter activity content
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_content( $content ) {

		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'profile_fields', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter text
	 *
	 * @param string $content Text content.
	 *
	 * @return string
	 */
	private function get_filtered_content( $content ) {
		return bp_profanity_filter_get_parsed_content( $content );
	}

	/**
	 * Notify admin when profanity content posted in activity or activity comment
	 *
	 * @param int   $user_id          ID for the user whose profile is being saved.
	 * @param array $posted_field_ids Array of field IDs that were edited.
	 * @param bool  $errors           Whether or not any errors occurred.
	 * @param array $old_values       Array of original values before update.
	 * @param array $new_values       Array of newly saved values after update.
	 */
	public function notify_admin( $user_id, $posted_field_ids, $errors, $old_values, $new_values ) {

		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable ) {
			return;
		}

		$has_profanity_content = false;

		foreach ( $new_values as $new_value ) {

			if ( ! empty( $new_value['value'] ) && bp_profanity_filter_has_profanity_content( $new_value['value'] ) ) {
				$has_profanity_content = true;
				break;
			}
		}

		if ( $has_profanity_content ) {
			$email = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );

			$subject = __( 'A user has posted profanity content while updating his profile', 'buddypress-profanity-filter' );

			$profile_link = bp_profanity_get_user_url( $user_id ) . bp_get_profile_slug();

			$content = <<<EOF
	Hello Admin,
	
	A user has posted profanity content in their profile.
	
	User Profile: {$profile_link}
EOF;


			wp_mail( $email, $subject, $content );
		}
	}
}