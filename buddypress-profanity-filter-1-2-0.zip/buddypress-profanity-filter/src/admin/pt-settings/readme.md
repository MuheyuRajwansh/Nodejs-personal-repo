@package pt-settings
#version 1.0.5
Added reset/set functions for panels & sections.

#version 1.0.3

PT Settings is the internal settings framework developed by BuddyDev/PressThemes team.