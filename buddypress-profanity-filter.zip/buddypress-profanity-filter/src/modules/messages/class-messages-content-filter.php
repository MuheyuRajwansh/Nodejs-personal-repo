<?php
/**
 * Message content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Messages;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class BPCF_Messages_Content_Filter
 */
class Messages_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup message hooks
	 */
	public function setup() {
		add_filter( 'bp_get_message_thread_subject', array( $this, 'filter_message_thread_subject' ) );
		add_filter( 'bp_get_message_thread_excerpt', array( $this, 'filter_message_thread_excerpt' ) );
		add_filter( 'bp_get_the_thread_subject', array( $this, 'filter_message_subject' ) );
		add_filter( 'bp_get_the_thread_message_content', array( $this, 'filter_message_content' ) );
		//add_filter( 'bp_get_message_thread_content', array( $this, 'filter_message_thread_content' ) );
		//add_filter( 'bp_get_messages_subject_value', array( $this, 'filter_messages_subject_value' ) );
		//add_filter( 'bp_get_messages_content_value', array( $this, 'filter_messages_content_value' ) );
		//add_filter( 'bp_get_message_notice_subject', array( $this, 'filter_message_notice_subject' ) );
		//add_filter( 'bp_get_message_notice_text', array( $this, 'filter_message_notice_text' ) );

		// Notify admin when profanity message/reply was send.
		add_action( 'messages_message_sent', array( $this, 'notify_admin' ) );

		// for BuddyPress Better Message.
		add_filter( 'bp_better_messages_pre_format_message', array( $this, 'filter_message_content' ) );

		add_filter( 'bb_nouveau_ajax_messages_send_reply_success', array( $this, 'bb_filter_send_reply' ) );
	}

	/**
	 * Filter message thread subject
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_message_thread_subject( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'message_thread_subject', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter message thread excerpt
	 *
	 * @param string $excerpt Content.
	 *
	 * @return string
	 */
	public function filter_message_thread_excerpt( $excerpt ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'message_thread_excerpt', $enable_for, true ) ) {
			return $this->get_filtered_content( $excerpt );
		}

		return $excerpt;
	}

	/**
	 * Filter thread message content
	 *
	 * @param string $subject Content.
	 *
	 * @return string
	 */
	public function filter_message_subject( $subject ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'single_message_subject', $enable_for, true ) ) {
			return $this->get_filtered_content( $subject );
		}

		return $subject;
	}

	/**
	 * Filter thread message content
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_message_content( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'single_message_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter send reply response
	 *
	 * @param array $response Response.
	 *
	 * @return array
	 */
	public function bb_filter_send_reply( $response ) {

		if ( is_array( $response ) && ! empty( $response['messages'] ) ) {
			foreach ( (array) $response['messages'] as $index => $message ) {

				if ( ! is_array( $message ) ) {
					continue;
				}

				if ( ! empty( $message['content'] ) && bp_profanity_filter_has_profanity_content( $message['content'] ) ) {
					$message['content'] = bp_profanity_filter_get_parsed_content( $message['content'] );
				}

				if ( ! empty( $message['excerpt'] ) && bp_profanity_filter_has_profanity_content( $message['excerpt'] ) ) {
					$message['excerpt'] = bp_profanity_filter_get_parsed_content( $message['excerpt'] );
				}

				$response['messages'][ $index ] = $message;
			}
		}

		return $response;
	}

	/**
	 * Filter message thread content
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_message_thread_content( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'activity_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter message subject value
	 *
	 * @param string $subject Content.
	 *
	 * @return string
	 */
	public function filter_messages_subject_value( $subject ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'activity_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $subject );
		}

		return $subject;
	}

	/**
	 * Filter message content value
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public function filter_messages_content_value( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'activity_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter notice subject
	 *
	 * @param string $subject Content.
	 *
	 * @return string
	 */
	public function filter_message_notice_subject( $subject ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'message_notice_subject', $enable_for, true ) ) {
			return $this->get_filtered_content( $subject );
		}

		return $subject;
	}

	/**
	 * Filter notice text
	 *
	 * @param string $text Text.
	 *
	 * @return string
	 */
	public function filter_message_notice_text( $text ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'message_notice_text', $enable_for, true ) ) {
			return $this->get_filtered_content( $text );
		}

		return $text;
	}

	/**
	 * Filter text
	 *
	 * @param string $content Text content.
	 *
	 * @return string
	 */
	private function get_filtered_content( $content ) {
		return bp_profanity_filter_get_parsed_content( $content );
	}

	/**
	 * Notify admin when profanity content posted in groups
	 *
	 * @param \BP_Messages_Message $message Message object. Passed by reference.
	 */
	public function notify_admin( $message ) {

		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable ) {
			return;
		}

		$has_profanity = false;

		if ( bp_profanity_filter_has_profanity_content( $message->subject ) ) {
			$has_profanity = true;
		} elseif ( bp_profanity_filter_has_profanity_content( $message->message ) ) {
			$has_profanity = true;
		}

		if ( $has_profanity ) {
			$email = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );

			$subject = __( 'New content containing profanity was posted in a private message', 'buddypress-profanity-filter' );

			$content = 'Subject: ' . $message->subject . PHP_EOL;
			$content .= 'Message: ' . $message->message;

			$thread_id   = messages_get_message_thread_id( $message->id );
			$thread_link = trailingslashit( bp_displayed_user_domain() . bp_get_messages_slug() . '/view' . $thread_id );

			$content .= sprintf( "\nLink: %s", esc_url( $thread_link ) );
			wp_mail( $email, $subject, $content );
		}
	}
}
