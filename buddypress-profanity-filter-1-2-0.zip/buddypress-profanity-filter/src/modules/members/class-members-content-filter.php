<?php
/**
 * Class members content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Members;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class Members_Content_Filter
 */
class Members_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup members hooks
	 */
	private function setup() {
		add_filter( 'bp_get_mentioned_user_display_name', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_member_user_nicename', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_member_name', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_member_profile_data', array( $this, 'filter_text' ) );
		// add_filter( 'bp_get_member_profile_data_' . $profile_data[ $r['field'] ]['field_type'], $data, $r );.
		// add_filter( 'bp_get_the_profile_field_value', array( $self, '' ) );.
		add_filter( 'bp_get_profile_field_data', array( $this, 'filter_text' ) );

		// add_filter( 'bp_get_user_firstname', array( $self, '' ) );.
		add_filter( 'bp_displayed_user_fullname', array( $this, 'filter_text' ) );
		add_filter( 'bp_get_loggedin_user_fullname', array( $this, 'filter_text' ) );
		// add_filter( 'bp_get_displayed_user_username', $username );.
		// add_filter( 'bp_get_loggedin_user_username', $username );.
	}

	/**
	 * Filter text
	 *
	 * @param string $text Text content.
	 *
	 * @return string
	 */
	public function filter_text( $text ) {
		return bp_profanity_filter_get_parsed_content( $text );
	}
}