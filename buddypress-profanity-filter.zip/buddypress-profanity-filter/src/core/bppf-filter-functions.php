<?php
/**
 * Core functions
 *
 * @package BuddyPress_Profanity_Filter
 */

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Get default settings.
 *
 * @return array
 */
function bp_profanity_filter_get_default_settings() {
	return array(
		'enable_for'          => array(),
		'profanity_keywords'  => '',
		'case_matching'       => 'insensitive',
		'strict_filter'       => 0,
		'filter_character'    => '*',
		'word_rendering'      => 'first_last',
		'notify_admin'        => 0,
		'notification_emails' => get_option( 'admin_email' ),
	);
}

/**
 * Settings options
 *
 * @param string $option_key Option key.
 * @param mixed  $default Default value for option key.
 *
 * @return mixed
 */
function bp_profanity_filter_get_option( $option_key, $default = null ) {

	$settings = get_option( 'bp_profanity_filter_settings', bp_profanity_filter_get_default_settings() );

	if ( isset( $settings[ $option_key ] ) ) {
		return $settings[ $option_key ];
	}

	return $default;
}

/**
 * Check if content has profanity keywords into it or not
 *
 * @param string $content Content to check.
 *
 * @return bool false on failure.
 */
function bp_profanity_filter_has_profanity_content( $content ) {

	$has_content = false;

	if ( empty( $content ) ) {
		return $has_content;
	}

	$profanity_keywords = bp_profanity_filter_get_profanity_keywords();

	if ( empty( $profanity_keywords ) ) {
		return $has_content;
	}

	foreach ( $profanity_keywords as $keyword ) {
		$keyword = trim( $keyword );

		if ( bp_profanity_filter_has_profanity_keyword( $keyword, $content ) ) {
			$has_content = true;
			break;
		}
	}

	return $has_content;
}

/**
 * Check if profanity keyword exists or not
 *
 * @param string $keyword Keyword.
 * @param string $content Content.
 *
 * @return false|int
 */
function bp_profanity_filter_has_profanity_keyword( $keyword, $content ) {

	if ( empty( $keyword ) || empty( $content ) ) {
		return false;
	}

	$case_matching = bp_profanity_filter_get_option( 'case_matching', 'insensitive' );
	$strict_filter = bp_profanity_filter_get_option( 'strict_filter', 0 );
	$keyword       = str_replace( '/', '\\/', preg_quote( $keyword ) );
	$pattern       = ( $strict_filter ) ? "/$keyword/" : "/\b($keyword)\b/";

	if ( 'insensitive' === $case_matching ) {
		$pattern = $pattern . 'i';
	}

	return preg_match( $pattern, $content );
}

/**
 * Return filter content
 *
 * @param string $content Content.
 *
 * @return string
 */
function bp_profanity_filter_get_parsed_content( $content ) {

	if ( empty( $content ) || ! bp_profanity_filter_has_profanity_content( $content ) ) {
		return $content;
	}

	$profanity_keywords = bp_profanity_filter_get_profanity_keywords();

	if ( empty( $profanity_keywords ) ) {
		return $content;
	}

	$case_matching = bp_profanity_filter_get_option( 'case_matching', 'insensitive' );
	$strict_filter = bp_profanity_filter_get_option( 'strict_filter', 0 );

	if ( $strict_filter ) {
		$replaced_keywords = array_map( 'bp_profanity_filter_get_replaced_profanity_keyword', $profanity_keywords );

		if ( 'sensitive' === $case_matching ) {
			return str_replace( $profanity_keywords, $replaced_keywords, $content );
		}

		return str_ireplace( $profanity_keywords, $replaced_keywords, $content );
	}

	foreach ( $profanity_keywords as $keyword ) {
		$keyword          = trim( $keyword );
		$filtered_keyword = bp_profanity_filter_get_replaced_profanity_keyword( $keyword );

		$keyword = str_replace( '/', '\\/', preg_quote( $keyword ) );
		$pattern = "/\b($keyword)\b/";

		if ( 'insensitive' === $case_matching ) {
			$pattern .= 'i';
		}

		$content = preg_replace( $pattern, $filtered_keyword, $content );
	}

	return $content;
}

/**
 * Get filtered keyword
 *
 * @param string $keyword Keyword.
 *
 * @return string
 */
function bp_profanity_filter_get_replaced_profanity_keyword( $keyword ) {
	$keyword          = trim( $keyword );
	$word_rendering   = bp_profanity_filter_get_option( 'word_rendering', 'first_last' );
	$filter_character = bp_profanity_filter_get_option( 'filter_character', '*' );

	if ( 'first' === $word_rendering ) {
		$keyword = substr( $keyword, 0, 1 ) . str_repeat( $filter_character, strlen( substr( $keyword, 1 ) ) );
	} elseif ( 'first_last' === $word_rendering ) {
		$keyword = substr( $keyword, 0, 1 ) . str_repeat( $filter_character, strlen( substr( $keyword, 2 ) ) ) . substr( $keyword, - 1, 1 );
	} elseif ( 'last' === $word_rendering ) {
		$keyword = str_repeat( $filter_character, strlen( $keyword ) - 1 ) . substr( $keyword, - 1, 1 );
	} else {
		$keyword = str_repeat( $filter_character, strlen( substr( $keyword, 0 ) ) );
	}

	return $keyword;
}

/**
 * Get profanity keywords
 *
 * @return array
 */
function bp_profanity_filter_get_profanity_keywords() {
	$profanity_keywords = bp_profanity_filter_get_option( 'profanity_keywords' );

	if ( empty( $profanity_keywords ) ) {
		return array();
	}

	$profanity_keywords = explode( ',', $profanity_keywords );
	$profanity_keywords = array_unique( $profanity_keywords );
	$profanity_keywords = array_map( 'trim', $profanity_keywords );

	return $profanity_keywords;
}

/**
 * Checks/sets the state if admin was notified.
 *
 * It is not a great implementation and should be discouraged.
 * We are adding it for quick turnaround for the time being.
 *
 * @param bool $update whether to set the notification state.
 *
 * @return bool
 */
function bp_profanity_was_admin_notified( $update = false ) {
	static $notified = null;

	if ( is_null( $notified ) && $update ) {
		$notified = true;
	}

	return $notified;
}

/**
 * Retrieves user url
 *
 * @param int $user_id User id.
 *
 * @return string
 */
function bp_profanity_get_user_url( $user_id, $nice_name = false, $user_login = false ) {

	if ( function_exists( 'bp_members_get_user_url' ) ) {
		return bp_members_get_user_url( $user_id );
	}

	return bp_core_get_user_domain( $user_id, $nice_name, $user_login );
}