<?php
/**
 * Comment content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Comment;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class Comment_Content_Filter
 */
class Comment_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup message hooks
	 */
	public function setup() {
		add_filter( 'get_comment_text', array( $this, 'filter_text' ) );
		add_filter( 'comment_excerpt', array( $this, 'filter_excerpt' ) );

		add_action( 'comment_post', array( $this, 'notify_admin' ), 10, 3 );
	}

	/**
	 * Filter comment text
	 *
	 * @param string $text Comment text.
	 *
	 * @return string
	 */
	public function filter_text( $text ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'comment_text', $enable_for, true ) ) {
			return $this->get_filtered_content( $text );
		}

		return $text;
	}

	/**
	 * Filter Post excerpt
	 *
	 * @param string $excerpt Post excerpt.
	 *
	 * @return string
	 */
	public function filter_excerpt( $excerpt ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'comment_excerpt', $enable_for, true ) ) {
			return $this->get_filtered_content( $excerpt );
		}

		return $excerpt;
	}

	/**
	 * Filter text
	 *
	 * @param string $content Text content.
	 *
	 * @return string
	 */
	private function get_filtered_content( $content ) {
		return bp_profanity_filter_get_parsed_content( $content );
	}

	/**
	 * On post insertion
	 *
	 * @param int        $comment_id  Comment id.
	 * @param int|string $approved    Weather approved or not.
	 * @param array      $commentdata Comment data.
	 */
	public function notify_admin( $comment_id, $approved, array $commentdata ) {

		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable || bp_profanity_was_admin_notified() ) {
			return;
		}

		if ( bp_profanity_filter_has_profanity_content( $commentdata['comment_content'] ) ) {
			$email = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );

			$subject = __( 'New profanity content was posted in comment.', 'buddypress-profanity-filter' );

			$message = sprintf( 'Comment content: %s', $commentdata['comment_content'] );

			$message .= sprintf( "\nLink: %s", esc_url( get_edit_comment_link( $comment_id ) ) );
			bp_profanity_was_admin_notified( true );
			wp_mail( $email, $subject, $message );
		}
	}
}
