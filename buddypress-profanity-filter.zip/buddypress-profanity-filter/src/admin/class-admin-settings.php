<?php
/**
 * Admin Settings Helper class.
 *
 * @package BuddyPress_Profanity_Filter
 */
namespace BuddyPress_Profanity_Filter\Admin;

use \Press_Themes\PT_Settings\Page;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class Admin_Settings_Helper
 */
class Admin_Settings {

	/**
	 * Admin Menu slug
	 *
	 * @var string
	 */
	private $menu_slug;

	/**
	 * Used to keep a reference of the Page, It will be used in rendering the view.
	 *
	 * @var \Press_Themes\PT_Settings\Page
	 */
	private $page;


	/**
	 * Setup admin section
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup settings class
	 */
	private function setup() {
		$this->menu_slug = 'bp-profanity-filter-settings';

		add_filter( 'plugin_action_links_' . bp_profanity_filter()->get_basename(), array( $this, 'add_plugin_row_settings_link' ) );

		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
	}

	/**
	 * Adds settings and Documentation links to the plugin row
	 *
	 * @param array $actions links to be shown in the plugin list context.
	 *
	 * @return array
	 */
	public function add_plugin_row_settings_link( $actions ) {
		$actions['view-settings'] = sprintf( '<a href="%1$s" title="%2$s">%3$s</a>', add_query_arg( array( 'page' => $this->menu_slug ), admin_url( 'options-general.php' ) ), __( 'BuddyPress Profanity Filter Settings', 'buddypress-profanity-filter' ), __( 'Settings', 'buddypress-profanity-filter' ) );
		$actions['view-docs']     = sprintf( '<a href="%1$s" title="%2$s" target="_blank">%2$s</a>', 'https://buddydev.com/docs/buddypress-profanity-filter/', _x( 'Documentation', 'plugin row link label', 'buddypress-profanity-filter' ) );

		return $actions;
	}

	/**+
	 * Add Menu
	 */
	public function add_menu() {
		add_options_page(
			_x( 'BP Profanity Filter', 'Admin settings page title', 'buddypress-profanity-filter' ),
			_x( 'BP Profanity Filter', 'Admin settings menu label', 'buddypress-profanity-filter' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render' )
		);
	}

	/**
	 * Show/render the setting page
	 */
	public function render() {
		$this->page->render();
	}

	/**
	 * Is it the setting page?
	 *
	 * @return bool
	 */
	private function needs_loading() {

		global $pagenow;

		// We need to load on options.php otherwise settings won't be reistered.
		if ( 'options.php' === $pagenow ) {
			return true;
		}

		if ( isset( $_GET['page'] ) && $_GET['page'] === $this->menu_slug ) {
			return true;
		}

		return false;
	}

	/**
	 * Initialize the admin settings panel and fields
	 */
	public function init() {

		if ( ! $this->needs_loading() ) {
			return;
		}

		$page = new Page( 'bp_profanity_filter_settings' );

		// General settings tab.
		$panel = $page->add_panel( 'general', _x( 'General', 'Admin settings panel title', 'buddypress-profanity-filter' ) );

		//$general_settings = $general->add_section( 'general_settings', _x( 'General Settings', 'Admin settings section title', 'buddypress-profanity-filter' ) );

		$default = bp_profanity_filter_get_default_settings();

		$panel->add_section( 'general-content-types', __( 'Enabled content types', 'buddypress-profanity-filter' ) )->add_field(
			array(
				'name'    => 'enable_for',
				'label'   => _x( 'Enable profanity filter for', 'Admin settings', 'buddypress-profanity-filter' ),
				'type'    => 'multicheck',
				'options' => $this->get_enabled_for_options(),
				'default' => $default['enable_for'],
				'desc'    => __( 'Please enable the content types you want to be checked for profanity.', 'buddypress-profanity-filter' ),
			)
		);

		$panel->add_section( 'general-profanity-words', __( 'Profanity Words', 'buddypress-profanity-filter' ) )->add_fields(
			array(
				array(
					'name'    => 'profanity_keywords',
					'label'   => _x( 'Words to remove', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'rawtext',
					'default' => $default['profanity_keywords'],
					'desc'    => __( 'Please add a list of profanity words separated by comma. The plugin will check for these words and mark any content containing them as content with profanity.', 'buddypress-profanity-filter' ),
				),
				array(
					'name'    => 'case_matching',
					'label'   => _x( 'Case matching type', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'radio',
					'options' => array(
						'sensitive'   => __( 'Case Sensitive', 'buddypress-profanity-filter' ),
						'insensitive' => __( 'Case Insensitive (recommended)', 'buddypress-profanity-filter' ),
					),
					'default' => $default['case_matching'],
					'desc'    => __( 'You can enable case sensitive or insensitive matching for the profanity words specified above.', 'buddypress-profanity-filter' ),
				),
				array(
					'name'    => 'strict_filter',
					'label'   => _x( 'Strict filtering', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'radio',
					'options' => array(
						1 => __( 'On', 'buddypress-profanity-filter' ),
						0 => __( 'Off', 'buddypress-profanity-filter' ),
					),
					'desc'    => __( 'If strict filtering is ON, even parts of words are matched. e.g. "crap" matches "crappy deal" or "scrap" too. If OFF, It will only match full words, e.g "crap" matches "Oh! crap" but not with "crappy deal" or "scrap".', 'buddypress-profanity-filter' ),
					'default' => $default['strict_filter'],
				),
				array(
					'name'    => 'filter_character',
					'label'   => _x( 'Filter Character', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'select',
					'options' => $this->get_filter_characters(),
					'default' => $default['filter_character'],
					'desc'    => __( 'It is used as the replacement character for the parts of matched profanity words.', 'buddypress-profanity-filter' ),
				),
				array(
					'name'    => 'word_rendering',
					'label'   => _x( 'Word Rendering', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'radio',
					'options' => array(
						'first'      => __( 'First character retained           [e.g. hello becomes h****]', 'buddypress-profanity-filter' ),
						'first_last' => __( 'First and last character retained  [e.g. hello becomes h***o]', 'buddypress-profanity-filter' ),
						'last'       => __( 'Last character retained            [e.g. hello becomes ****o]', 'buddypress-profanity-filter' ),
						'all'        => __( 'Replace whole word                 [e.g. hello becomes *****]', 'buddypress-profanity-filter' ),
					),
					'default' => $default['word_rendering'],
					'desc'    => __( 'It allows you control how the matched profanity words will be replaced.', 'buddypress-profanity-filter' ),
				),
			)
		);

		$panel->add_section( 'genera-notifications', __( 'Notifications', 'buddypress-profanity-filter' ) )->add_fields(
			array(
				array(
					'name'    => 'notify_admin',
					'label'   => _x( 'Notify admin', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'radio',
					'options' => array(
						1 => __( 'Yes', 'buddypress-profanity-filter' ),
						0 => __( 'No', 'buddypress-profanity-filter' ),
					),
					'default' => $default['notify_admin'],
					'desc'    => __( 'Notify admin when any content with profanity keywords is posted.', 'buddypress-profanity-filter' ),
				),
				array(
					'name'    => 'notification_emails',
					'label'   => _x( 'Notification email', 'Admin settings', 'buddypress-profanity-filter' ),
					'type'    => 'text',
					'default' => $default['notification_emails'],
					'desc'    => __( 'Email address to be notified.', 'buddypress-profanity-filter' ),
				),
			)
		);
		// Save page for future reference.
		$this->page = $page;

		do_action( 'bp_profanity_filter_admin_settings', $page );

		// allow enabling options.
		$page->init();
	}

	/**
	 * Get filter characters
	 */
	private function get_filter_characters() {
		$filter_characters = array(
			'*' => __( '(*) Asterisk', 'buddypress-profanity-filter' ),
			'$' => __( '($) Dollar', 'buddypress-profanity-filter' ),
			'?' => __( '(?) Question', 'buddypress-profanity-filter' ),
			'!' => __( '(!) Exclamation', 'buddypress-profanity-filter' ),
			'~' => __( '(~) Tilde', 'buddypress-profanity-filter' ),
		);

		return $filter_characters;
	}

	/**
	 * Get enabled for options
	 *
	 * @return array
	 */
	private function get_enabled_for_options() {
		$options = array(
			'post_title'      => __( 'Post Title', 'buddypress-profanity-filter' ),
			'post_content'    => __( 'Post Content', 'buddypress-profanity-filter' ),
			'post_excerpt'    => __( 'Post Excerpt', 'buddypress-profanity-filter' ),
			'comment_text'    => __( 'Comment Content', 'buddypress-profanity-filter' ),
			'comment_excerpt' => __( 'Comment Excerpt', 'buddypress-profanity-filter' ),
		);

		if ( bp_is_active( 'activity' ) ) {
			$options['activity_content']  = __( 'BuddyPress - Activity Posts', 'buddypress-profanity-filter' );
			$options['activity_comments'] = __( 'BuddyPress - Activity Comments', 'buddypress-profanity-filter' );
		}

		if ( bp_is_active( 'messages' ) ) {
			$options['message_thread_subject'] = __( 'BuddyPress - Private Messages List Subject', 'buddypress-profanity-filter' );
			$options['message_thread_excerpt'] = __( 'BuddyPress - Private Message Excerpt', 'buddypress-profanity-filter' );
			$options['single_message_subject'] = __( 'BuddyPress - Private Message Subject', 'buddypress-profanity-filter' );
			$options['single_message_content'] = __( 'BuddyPress - Private Message Content', 'buddypress-profanity-filter' );
			//$options['message_notice_subject'] = __( 'Notice Message subject', 'buddypress-profanity-filter' );
			//$options['message_notice_text']    = __( 'Notice message content', 'buddypress-profanity-filter' );
		}

		if ( bp_is_active( 'xprofile' ) ) {
			$options['profile_fields'] = __( 'BuddyPress - Profile Fields', 'buddypress-profanity-filter' );
		}

		/*
		if ( bp_is_active( 'groups' ) ) {
			$options['group_name']         = __( 'BuddyPress - Group name', 'buddypress-profanity-filter' );
			$options['group_description']  = __( 'BuddyPress - Group description', 'buddypress-profanity-filter' );
			$options['group_desc_excerpt'] = __( 'BuddyPress - Group description excerpt', 'buddypress-profanity-filter' );
		}
		*/

		if ( function_exists( 'bbpress' ) ) {
			$options['forum_topic_title']         = __( 'bbPress - Forum Topic Title', 'buddypress-profanity-filter' );
			$options['forum_topic_archive_title'] = __( 'bbPress - Forum Topic Archive Title', 'buddypress-profanity-filter' );
			$options['forum_topic_content']       = __( 'bbPress - Forum Topic Content', 'buddypress-profanity-filter' );
			$options['forum_topic_excerpt']       = __( 'bbPress - Forum Topic Excerpt', 'buddypress-profanity-filter' );
			$options['forum_reply_title']         = __( 'bbPress - Forum Reply Title', 'buddypress-profanity-filter' );
			$options['forum_reply_content']       = __( 'bbPress - Forum Reply Content', 'buddypress-profanity-filter' );
			$options['forum_reply_excerpt']       = __( 'bbPress - Forum Reply Excerpt', 'buddypress-profanity-filter' );
			$options['forum_title']               = __( 'bbPress - Forum Title', 'buddypress-profanity-filter' );
			$options['forum_archive_title']       = __( 'bbPress - Forum Archive Title', 'buddypress-profanity-filter' );
			$options['forum_content']             = __( 'bbPress - Forum Content', 'buddypress-profanity-filter' );
		}

		return $options;
	}
}