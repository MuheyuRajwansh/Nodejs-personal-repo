<?php
/**
 * Post content filter
 *
 * @package BuddyPress_Profanity_Filter
 */

namespace BuddyPress_Profanity_Filter\Modules\Post;

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

/**
 * Class Post_Content_Filter
 */
class Post_Content_Filter {

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();

		$self->setup();
	}

	/**
	 * Setup message hooks
	 */
	public function setup() {
		add_filter( 'the_title', array( $this, 'filter_title' ) );
		add_filter( 'the_content', array( $this, 'filter_content' ) );
		add_filter( 'the_excerpt', array( $this, 'filter_excerpt' ) );

		add_action( 'wp_insert_post', array( $this, 'notify_admin' ), 10, 2 );
	}

	/**
	 * Filter Post title for profanity keywords
	 *
	 * @param string $title Post title.
	 *
	 * @return string
	 */
	public function filter_title( $title ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'post_title', $enable_for, true ) ) {
			return $this->get_filtered_content( $title );
		}

		return $title;
	}

	/**
	 * Filter post content
	 *
	 * @param string $content Post Content.
	 *
	 * @return string
	 */
	public function filter_content( $content ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'post_content', $enable_for, true ) ) {
			return $this->get_filtered_content( $content );
		}

		return $content;
	}

	/**
	 * Filter Post excerpt
	 *
	 * @param string $excerpt Post excerpt.
	 *
	 * @return string
	 */
	public function filter_excerpt( $excerpt ) {
		$enable_for = (array) bp_profanity_filter_get_option( 'enable_for', array() );

		if ( in_array( 'post_excerpt', $enable_for, true ) ) {
			return $this->get_filtered_content( $excerpt );
		}

		return $excerpt;
	}

	/**
	 * Filter text
	 *
	 * @param string $content Text content.
	 *
	 * @return string
	 */
	private function get_filtered_content( $content ) {
		return bp_profanity_filter_get_parsed_content( $content );
	}

	/**
	 * On post insertion
	 *
	 * @param int      $post_id Post id.
	 * @param \WP_Post $post    Post object.
	 */
	public function notify_admin( $post_id, $post ) {

		$is_enable = bp_profanity_filter_get_option( 'notify_admin', 0 );

		if ( ! $is_enable  || bp_profanity_was_admin_notified() ) {
			return;
		}

		$has_profanity = false;
		$content       = '';

		if ( bp_profanity_filter_has_profanity_content( $post->post_title ) ) {
			$has_profanity = true;
			$content       = $post->post_title;
		} elseif ( bp_profanity_filter_has_profanity_content( $post->post_content ) ) {
			$has_profanity = true;
			$content       = $post->post_content;
		}

		if ( $has_profanity ) {
			$email = bp_profanity_filter_get_option( 'notification_emails', get_option( 'admin_email' ) );

			$subject = __( 'New profanity content was posted in post.', 'buddypress-profanity-filter' );

			$message = sprintf( 'Post content: %s', $content );
			$message .= sprintf( "\nLink: %s", esc_url( get_edit_post_link( $post ) ) );
			bp_profanity_was_admin_notified( true );
			wp_mail( $email, $subject, $message );
		}
	}
}
