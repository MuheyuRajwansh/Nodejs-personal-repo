<?php
/**
 * Plugin Name: BuddyPress Profanity Filter
 * Plugin URI: https://buddydev.com/plugins/buddypress-profanity-filter/
 * Description: Keeping the community Clean with BuddyPress.
 * Version: 1.2.0
 * Author: BuddyDev
 * Author URI: https://buddydev.com
 **/

// Exit if accessed directly over web.
defined('ABSPATH') || exit;

use BuddyPress_Profanity_Filter\Admin\Admin_Settings;
use BuddyPress_Profanity_Filter\Core\Autoloader;
use BuddyPress_Profanity_Filter\Modules\Post\Post_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Comment\Comment_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Activity\Activity_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Members\Members_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Groups\Groups_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Messages\Messages_Content_Filter;
use BuddyPress_Profanity_Filter\Modules\Profile_Fields\Profile_Fields_Filter;
use BuddyPress_Profanity_Filter\Modules\Forum\Forum_Content_Filter;

/**
 * Class BP_Profanity_Filter
 */
class BP_Profanity_Filter {

	/**
	 * Singleton Instance
	 *
	 * @var BP_Profanity_Filter
	 */
	private static $instance = null;

	/**
	 * Plugins directory path
	 *
	 * @var string
	 */
	private $path;

	/**
	 * Plugins directory url
	 *
	 * @var string
	 */
	private $url;

	/**
	 * Basename.
	 *
	 * @var string
	 */
	private $basename;

	/**
	 * BP_Profanity_Filter constructor.
	 */
	private function __construct() {
		$this->path     = plugin_dir_path( __FILE__ );
		$this->url      = plugin_dir_url( __FILE__ );
		$this->basename = plugin_basename( __FILE__ );
		$this->boot();
	}

	/**
	 * Class instance
	 *
	 * @return BP_Profanity_Filter
	 */
	public static function get_instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Boot class
	 */
	private function boot() {

		register_activation_hook( __FILE__, array( $this, 'on_activation' ) );

		add_action( 'bp_loaded', array( $this, 'load' ) );

		add_action( 'plugins_loaded', array( $this, 'load_admin' ), 9998 ); // pt-settings-1.0.2.
	}

	/**
	 * On plugin activation add default settings if previously not saved
	 */
	public function on_activation() {

		if ( get_option( 'bp_profanity_filter_settings' ) ) {
			return;
		}

		require_once $this->path . 'src/core/bppf-filter-functions.php';

		update_option( 'bp_profanity_filter_settings', bp_profanity_filter_get_default_settings() );
	}

	/**
	 * Load plugins files
	 */
	public function load() {

		// Load autoloader.
		require_once $this->path . 'src/core/class-autoloader.php';

		// Register autoloader.
		spl_autoload_register( new Autoloader( 'BuddyPress_Profanity_Filter\\', __DIR__ . '/src/' ) );

		require_once $this->path . 'src/core/bppf-filter-functions.php';

		$this->setup();
	}

	/**
	 * Load admin.
	 */
	public function load_admin() {

		// Do not load.
		if ( ! is_admin() || wp_doing_ajax() ) {
			return;
		}

		if ( ! function_exists( 'bp_is_active' ) ) {
			return;
		}

		require_once $this->path . 'src/admin/pt-settings/pt-settings-loader.php';

		Admin_Settings::boot();
	}

	/**
	 * Load plugin core files and assets.
	 */
	private function setup() {
		//Members_Content_Filter::setup();

		Post_Content_Filter::boot();
		Comment_Content_Filter::boot();

		if ( bp_is_active( 'activity' ) ) {
			Activity_Content_Filter::boot();
		}

		/*if ( bp_is_active( 'groups' ) ) {
			Groups_Content_Filter::boot();
		}*/

		if ( bp_is_active( 'messages' ) ) {
			Messages_Content_Filter::boot();
		}

		if ( bp_is_active( 'xprofile' ) ) {
			Profile_Fields_Filter::boot();
		}

		if ( function_exists( 'bbpress' ) ) {
			Forum_Content_Filter::boot();
		}
	}

	/**
	 * Load text domain
	 */
	public function load_text_domain() {
		load_plugin_textdomain(
			'buddypress-profanity-filter',
			false,
			basename( dirname( __FILE__ ) ) . '/languages'
		);
	}

	/**
	 * Return path of plugin directory
	 *
	 * @return string
	 */
	public function get_path() {
		return $this->path;
	}

	/**
	 * Return url of plugin url
	 *
	 * @return string
	 */
	public function get_url() {
		return $this->url;
	}

	/**
	 * Return url of plugin url
	 *
	 * @return string
	 */
	public function get_basename() {
		return $this->basename;
	}
}

/**
 * Helper function to access the singleton instance.
 *
 * @return BP_Profanity_Filter
 */
function bp_profanity_filter() {
	return BP_Profanity_Filter::get_instance();
}

bp_profanity_filter();
